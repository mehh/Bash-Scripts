#!/bin/bash
#


# This function prints the hostname
_print_hostname()
{
  # Spacer
  printf "\n"

  # Check if figlet is available and config var set
  if [[ -x $(which figlet) &&  ! -z "$_bf_figlet_on" ]]; then
    # Check if lolcat is available and config var set
      #Print hostename with figlets
      _print_ascii_art "$_bf_hostname"
  else
    # No fancy ASCII art support available
    printf "\n${BOLD}"
    _print_centered_string "$_bf_hostname"
  fi
}


_print_cpuram()
{
  # OS dependent
  case $_bf_os_type in
  linux)
    if [[ -f /proc/cpuinfo ]]; then
      local cpu=$(grep -m 1 'model name' /proc/cpuinfo | cut -d: -f2 | sed -e 's/^ *//')
      local real_cores="$(grep -m 1 'cpu cores' /proc/cpuinfo | cut -d: -f2 | sed -e 's/^ *//')"
      local virt_cores="$(grep -m 1 'siblings' /proc/cpuinfo | cut -d: -f2 | sed -e 's/^ *//')"
    fi
    if [[ -x $(which free) ]]; then
      ram="$(free -m | awk '/^Mem:/{print $2}') MB RAM"
    fi

    local cpuram="$cpu $virt_cores/$real_cores (vCPU/CPU) - $ram"
    ;;
  osx)
    if [[ -x $(which sysctl) ]]; then
      local cpu=$(sysctl -n machdep.cpu.brand_string)
      local real_cores=$(sysctl -n machdep.cpu.core_count)
      local virt_cores=$(sysctl -n machdep.cpu.thread_count)
      local ram="$(system_profiler SPHardwareDataType | grep Memory | cut -d: -f2 | tr -d [:blank:]) RAM"
      local cpuram="$cpu $virt_cores/$real_cores (vCPU/CPU) - $ram"
    fi
    ;;
  *)
    local cpuram=
    ;;
  esac

  printf "${ORANGE}"
  _print_centered_string "$cpuram"
  printf "${NORMAL}"
}


_print_kernel()
{
  # Check for uname and retrieve kernel and architecture
  if [[ -x $(which uname) ]]; then
    local SYS_INFO="$(uname -srmo)"

    printf "${BETTER_YELLOW}"
    _print_centered_string "$SYS_INFO"
    printf "${NORMAL}"
  fi
}


_print_distro()
{
echo ''
}



_print_ext_ip()
{
  printf "${BETTER_GREY}"
  _print_centered_string "External IP: $_bf_ext_ip"
}


_print_ssh_status()
{
  if [[ ! -z $SSH_CLIENT ]]; then
    printf "${GREEN}\n"
    _print_centered_string "==> Connected through SSH: $SSH_CLIENT"
    printf "${NORMAL}\n"
  fi
}


_print_diskstats()
{
  if [[ -x $(which df) ]]; then
    # disk usage, don't show tmpfs, ecryptfs, encfs, bccfs, sfpfs
    local DISK_INFO=$(df -h -x tmpfs -x devtmpfs -x ecryptfs -x fuse.encfs -x bcfs -x afpfs -T)

    printf ${POWDER_BLUE}
    _print_centered_multiline "$DISK_INFO"
    # printf "%s\n" "$DISK_INFO" | boxes -d ada-box -ph8v1

    printf "${NORMAL}\n"
  fi
}


_print_lastlogins()
{
  if [[ -x $(which last) ]]; then
    local LAST_LOGINS=$(last -in 3 -ad)
    #local linecount=$(printf "%s\n" "$LAST_LOGINS" | grep -c '^')

    printf ${GREY}
    _print_centered_multiline "$LAST_LOGINS"

    printf "${NORMAL}\n"
  fi
}


_print_random_cmdinfo()
{
    if [[ -x $(which whatis) ]]; then
        local rnd_cmd_info="${BETTER_GREY}Random command info:${GREY}"$'\n'
        rnd_cmd_info+=$(whatis $(ls /bin | shuf -n 1))

        _print_centered_multiline "$rnd_cmd_info"
        printf "${NORMAL}\n"
    fi
}


_print_reboot_info()
{
    printf "${BETTER_YELLOW}"
    _print_centered_string "Reboot required!"
    printf "\n${NORMAL}"
}


_bf_fortune()
{
  if [[ -x $(which fortune) ]]; then
    printf "\n\n${BETTER_GREY}"
    fortune
  fi
}
